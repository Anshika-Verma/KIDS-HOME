<!DOCTYPE html>
<html>
    <head>
        <title>Kids Home</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">  
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="css/main.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    </head>
    <style>     
        #image{
            border-radius: 10px 10px 10px 10px;
            border: 1px solid #B0c4DE;
        }
    </style>
    <body data-spy="scroll" data-target=".navbar" data-offset="50">
        <div class="container-fluid"> 
            <div class="row">
            <div class="col-lg-6">
                <div class="col-sm-6"><center><a href="index.php"><img src="image/logo/logo.jpg" style="margin-top: 10px;" alt="Logo" width="150" height="60" id="image"></a></center></div>
             </div> 
            <div class="col-lg-4">                 
                <form class="navbar-form navbar-right" method="post" action="search.php">              
                    <div class="input-group" style="padding-top: 10px;">
                        <input type="text" name="value" id="search" placeholder="Search" class="form-control">
                        <div class="input-group-btn">
                            <button class="btn btn-default" onclick="search()" style="margin-top: 8px;" name="search">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form> 
            </div>
        </div> 
        </div>
        <br>
        
        