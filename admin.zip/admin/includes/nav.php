<nav class="navbar navbar-default" data-spy="affix" data-offset-top="197"> 
    <div class="container-fluid">
         <div class="navbar-header">
             <button type="button" class="navbar-toggler navbar-toggler-right ml-auto" data-toggle="collapse" data-target=".navbar-collapse">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>                        
             </button>
             <a class="navbar-brand" href="index.php" title="Home"><i class="fas fa-home"></i></a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="#">Orders</a></li>
                <li><a href="#">Queries</a></li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Shopping
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="filter.php">Product</a></li>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <?php
              if(true)
              {
                echo '<li class="dropdown">
                      <a href="../dashboard.php" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Dashboard<b class="caret"></b></a>
                      <ul class="dropdown-menu">

                          <li class="divider"></li>
                          <li>
                              <a href="change_passwor.php"> Change Password</a>
                          </li>
                          <li class="divider"></li>
                          <li>
                              <a href="home.php?logout="1" "><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                          </li>
                      </ul>
                  </li>' ;
              }
              ?>        
        </ul>
   </div>
  </div>
</nav>
