<footer>
  <center>
   <div class="container-">
       <div class="row">
           <div class="col-lg-4 col-sm-4 col-xs-4">
            <h3><b>Kids Home</b></h3>
            </div>
            <div class="col-lg-4 col-sm-4 col-xs-4">
            <h3><b>Kids Home</b></h3>
            </div>
            <div class="col-lg-4 col-sm-4 col-xs-4">
            <h3><b>Kids Home</b></h3>
           </div> 
       </div>
      </div>
  </center>
</footer>
</body>
</html>