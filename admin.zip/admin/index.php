<?php
include('includes/header.php');
include('includes/nav.php');

?>
<section id="actions" class="py-4 mb-2 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <a data-toggle="modal" data-target="#addusermodal" class="btn btn-primary btn-block" href="#">               
                    <i class="fas fa-plus"></i> Add Products
                </a>
            </div>
            <div class="col-md-3">
                <a data-toggle="modal" data-target="#addcategorymodal" class="btn btn-success btn-block" href="#">
                <i class="fas fa-plus"></i> Add User
                </a>
            </div>
            <div class="col-md-3">
                <a data-toggle="modal" data-target="#addcategorymodal" class="btn btn-warning btn-block" href="#">
                <i class="fas fa-plus"></i> Add Product Stock 
                </a>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-10">
                <h3><i class="fas fa-cart-arrow-down"></i>Products For Sale</h3>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover table-striped">
                        <tr>
                            <td>S.NO</td>
                            <td>Product Name</td>
                            <td>Brand</td>
                            <td>Price</td>
                            <td>Product Category</td>
                            <td>Product Quantity</td>
                            <td>Edit</td>
                        </tr>
                        <?php
                        $con = mysqli_connect('localhost','root','','kids_home');
                        $sql = "SELECT * FROM product LIMIT 10";
                        $query = mysqli_query($con,$sql);
                        $result = mysqli_num_rows($query);
                        if($result>0)
                        {
                            while($row = mysqli_fetch_array($query,MYSQLI_ASSOC))
                            {
                                echo '<tr>';
                                echo '<td>'.$row['product_id'].'</td>';
                                echo '<td>'.$row['product_name'].'</td>';
                                echo '<td>'.$row['product_brand'].'</td>';
                                echo '<td>'.$row['product_price'].'</td>';
                                echo '<td>'.$row['product_category'].'</td>';
                                echo '<td>'.$row['product_quantity'].'</td>';
                                echo '<td><a href="#" class="btn btn-primary btn-block">Edit</a></td>';
                                echo '</tr>';
                            }
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade" id="addusermodal">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Add User</h5>
                        <button class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="register.php">
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="form-group">
                                 <label for="email">Email</label>
                                 <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="form-group">
                                 <label for="password">Password</label>
                                 <input type="password" class="form-control" name="password" required>
                            </div>
                            <div class="form-group">
                                 <label for="password2">Confirm Password</label>
                                 <input type="password" class="form-control" name="password1" required>
                            </div>  
                            <div class="form-group">
                                <button class="btn btn-primary" name="Save">Save Changes</button>
                            </div>    
                        </form>
                    </div>
                </div>
            </div>
        </div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<?php
include('includes/footer.php');
?>